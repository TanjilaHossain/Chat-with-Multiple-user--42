/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multi_chat;

import java.io.*;
import java.util.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import static multi_chat.server.ar;
import static multi_chat.server.ar2;
import static multi_chat.server.i;
//ArrayList<users> user  = new ArrayList();
// Server class
public class server 
{
 
    // Vector to store active clients
    static Vector<ClientHandler> ar = new Vector<>();
    static Vector<ClientHandler> ar2 = new Vector<>();
    static Vector<String> st = new Vector<>();
     
    // counter for clients
    static int i = 0;
 
    public static void main(String[] args) throws IOException 
    {
        // server is listening on port 1234
        ServerSocket ss = new ServerSocket(1234);
         
        Socket s;
        String username = "";
        String password = "";
        int quit = 0;
            
         
        // running infinite loop for getting
        // client request
        while (true) 
        {
            // Accept the incoming request
            s = ss.accept();
 
            System.out.println("New client request received : " + s);
             
            // obtain input and output streams
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            
             
            System.out.println("Creating a new handler for this client...");
            String sen = "You have to signup to continue\nWrite 'signup' to sigh up";
            String answer = "";
            
            
            try {
                dos.writeUTF(sen);
                answer = dis.readUTF();
                if(answer.equals("signup"))
                {
                    sen = "Enter username and password to register.\n Registration format : username#password\n";
                    dos.writeUTF(sen);
                    sen = dis.readUTF();
                    StringTokenizer st = new StringTokenizer(sen, "#");
                    username = st.nextToken();
                    password = st.nextToken();
                    
                   /* for (ClientHandler mc : server.ar) 
                    {
                        if(mc.username.equals(username))
                        {
                            dos.writeUTF("This username already exists!\n");
                            break;
                        }
                        else
                        {
                            dos.writeUTF("Welcome! You can now Login anytime with this username.\nDo you want to Login? If yes Enter 'login'\nIf you want to quit enter 'quit'\n");
                        }
                    }*/
                    
                    
                    
                    dos.writeUTF("Welcome! You can now Login anytime with this username.\nDo you want to Login? If yes Enter 'login'\nIf you want to quit enter 'quit'\n");

                    
                }
            }catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            // Create a new handler object for handling this request.
            ClientHandler mtch = new ClientHandler(s,username, dis, dos,username,password);
            //System.out.println(ar.get[0]);
 
            // Create a new Thread with this object.
            Thread t = new Thread(mtch);
             
            System.out.println("Adding this client to active client list");
 
            // add this client to active clients list
            ar.add(mtch);
 
            // start the thread.
            t.start();
 
            // increment i for new client.
            // i is used for naming only, and can be replaced
            // by any naming scheme
            i++;
 
        }
    }
}
 
// ClientHandler class
class ClientHandler implements Runnable 
{
    Scanner scn = new Scanner(System.in);
    private String name;
    final DataInputStream dis;
    final DataOutputStream dos;
    Socket s;
    boolean isloggedin;
    String username;
    String password;
    // constructor
    public ClientHandler(Socket s, String name,
                            DataInputStream dis, DataOutputStream dos,String username,String password) {
        this.dis = dis;
        this.dos = dos;
        this.name = name;
        this.s = s;
        this.username = username;
        this.password = password;
        this.isloggedin=true;
    }
 
    @Override
    public void run() {
        //ClientHandler mc1;
        int lout = 0;
            String received; 
            String sen;
            String sen2;
            int quit = 0;
            //System.out.println(Server.ar.get(1));
            try{
                received = dis.readUTF();
                if(received.equals("login"))
                {
                    sen = "Enter username and password to login.\n login format : username#password\n";
                    dos.writeUTF(sen);
                    sen = dis.readUTF();
                    StringTokenizer st = new StringTokenizer(sen, "#");
                    username = st.nextToken();
                    password = st.nextToken();
                    int ff= 0;
                    for (ClientHandler mc : server.ar) 
                    {
                        // if the recipient is found, write on its
                        // output stream
                        System.out.println("........1..........");
                        if (mc.username.equals(username) ) 
                        {
                            ff=1;
                            System.out.println(".........2.........");
                            dos.writeUTF("Welcome! You are logged in.\nIf you want to logout enter 'logout' After receiving answer from another user\n");
                            ClientHandler mtch = new ClientHandler(s,name, dis, dos,username,password);

                            ar2.add(mtch);
                            break;
                        }
                        else
                        {
                            ff=0;
                            
                        }
                         
                    }
                     if(ff==0)
                     {
                         s.close();
                     
                     }
                }
                else if(received.equals("quit"))
                {
                    dos.writeUTF("quit");
                    s.close();
                    return;
                }
                
            }catch(Exception e)
            {
                e.printStackTrace();
            }
            System.out.println("........3...........");
            if(quit == 1)
            {
                try {
                s.close();
                } catch (IOException ex) {
                    Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            }
            
            
            int count = 0;                
            for (ClientHandler mc : server.ar2) 
            {
                count++;
                                                   
            }
            String str = Integer.toString(count);
            try {
                dos.writeUTF(str);
            } catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            //ClientHandler mc ;
            int ii=0;
            for (ClientHandler mc : server.ar2) 
            {
                try {
                    String clients  = server.ar2.get(ii).name;
                    System.out.println(clients);
                    dos.writeUTF(clients);//name hoilo vector[0][1]dhor
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                ii++;
            }
                            
                            
                    
 
            while (true) 
            {
                try
                {

                    // receive the string
                    received = dis.readUTF();

                    System.out.println(received);

                    if(received.equals("logout")){
                        this.isloggedin=false;
                        s.close();
                        break;
                    }
                    
                    int p=1;
                    String[] items = received.split("#");
                    int itemCount = items.length;
                    System.out.println(itemCount+"\n\n\n");
                    // break the string into message and recipient part
                    //String MsgToSend = items[0];
                    while(p<itemCount)
                    {
                        System.out.println(items[p]);
                        p++;
                    }
                    StringTokenizer st = new StringTokenizer(received, "#");
                    String MsgToSend = st.nextToken();
                    String recipient = null;
                    


                    // search for the recipient in the connected devices list.
                    // ar is the vector storing client of active users
                    /*
                   for (ClientHandler mc : server.ar) 
                    {
                        // if the recipient is found, write on its
                        // output stream
                        System.out.println(mc);
                        
                        if (mc.name.equals(recipient) && mc.isloggedin==true) 
                        {
                            mc.dos.writeUTF(this.name+" : "+MsgToSend);
                            break;
                        }
                        
                        
                    }
                    
                    */
                    for(int k = 1;k<itemCount;k++)
                    {
                        recipient = items[k];
                        if(recipient.equals("all")&& itemCount==2)
                        {
                            for (ClientHandler mc : server.ar) 
                            {
                                // if the recipient is found, write on its
                                // output stream
                                System.out.println(mc);

                                if (mc.isloggedin==true) 
                                {
                                    mc.dos.writeUTF(this.name+" : "+MsgToSend);
                                   // break;
                                }
                            }
                        }
                        else
                        {
                            for (ClientHandler mc : server.ar) 
                            {
                                // if the recipient is found, write on its
                                // output stream
                                System.out.println(mc);

                                if (mc.name.equals(recipient) && mc.isloggedin==true) 
                                {
                                    mc.dos.writeUTF(this.name+" : "+MsgToSend);
                                    break;
                                }
                            }
                        }
                    }
                    
                    
                    
                    
                } catch (IOException e) {

                    e.printStackTrace();
                }


            }
            try
            {
                // closing resources
                this.dis.close();
                this.dos.close();

            }catch(IOException e){
                e.printStackTrace();
            }
        }

    
}

